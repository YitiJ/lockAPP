package app.amazing.yiti.jeff.myapplication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import app.amazing.yiti.jeff.myapplication.days.Friday;
import app.amazing.yiti.jeff.myapplication.days.Monday;
import app.amazing.yiti.jeff.myapplication.days.Saturday;
import app.amazing.yiti.jeff.myapplication.days.Sunday;
import app.amazing.yiti.jeff.myapplication.days.Thursday;
import app.amazing.yiti.jeff.myapplication.days.Tuesday;
import app.amazing.yiti.jeff.myapplication.days.Wednesday;

public class Week extends AppCompatActivity implements View.OnClickListener{



        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_week);


            Button mondayBtn = findViewById(R.id.mondayBtn);
            Button tuesdayBtn = findViewById(R.id.tuesdayBtn);
            Button wednesdayBtn = findViewById(R.id.wednesdayBtn);
            Button thursdayBtn = findViewById(R.id.thursdayBtn);
            Button fridayBtn = findViewById(R.id.fridayBtn);
            Button saturdayBtn = findViewById(R.id.saturdayBtn);
            Button sundayBtn = findViewById(R.id.sundayBtn);

            mondayBtn.setOnClickListener(this);
            tuesdayBtn.setOnClickListener(this);
            thursdayBtn.setOnClickListener(this);
            wednesdayBtn.setOnClickListener(this);
            fridayBtn.setOnClickListener(this);
            sundayBtn.setOnClickListener(this);
            saturdayBtn.setOnClickListener(this);

        }

        protected void onResume(){// sets value of current limits
            super.onResume();

            TextView mon =  findViewById(R.id.monCur);
            mon.setText(Logic.getPlaceholder(0));
            TextView tue =  findViewById(R.id.tueCur);
            tue.setText(Logic.getPlaceholder(1));
            TextView wed =  findViewById(R.id.wedCur);
            wed.setText(Logic.getPlaceholder(2));
            TextView thur =  findViewById(R.id.thurCur);
            thur.setText(Logic.getPlaceholder(3));
            TextView fri =  findViewById(R.id.friCur);
            fri.setText(Logic.getPlaceholder(4));
            TextView sat =  findViewById(R.id.satCur);
            sat.setText(Logic.getPlaceholder(5));
            TextView sun =  findViewById(R.id.sunCur);
            sun.setText(Logic.getPlaceholder(6));
        }


        @Override
        public void onClick(View v){
            switch(v.getId()){
                case R.id.mondayBtn:
                    startActivity(new Intent(getApplicationContext(),Monday.class));
                    break;
                case R.id.tuesdayBtn:
                    startActivity(new Intent(getApplicationContext(),Tuesday.class));
                    break;
                case R.id.wednesdayBtn:
                    startActivity(new Intent(getApplicationContext(),Wednesday.class));
                    break;
                case R.id.thursdayBtn:
                    startActivity(new Intent(getApplicationContext(),Thursday.class));
                    break;
                case R.id.fridayBtn:
                    startActivity(new Intent(getApplicationContext(),Friday.class));
                    break;
                case R.id.saturdayBtn:
                    startActivity(new Intent(getApplicationContext(),Saturday.class));
                    break;
                case R.id.sundayBtn:
                    startActivity(new Intent(getApplicationContext(),Sunday.class));
                    break;
            }

            }
}
