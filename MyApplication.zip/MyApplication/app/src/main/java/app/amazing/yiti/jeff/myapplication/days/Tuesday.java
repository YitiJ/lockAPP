package app.amazing.yiti.jeff.myapplication.days;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import app.amazing.yiti.jeff.myapplication.Logic;
import app.amazing.yiti.jeff.myapplication.R;
import app.amazing.yiti.jeff.myapplication.Week;

public class Tuesday extends AppCompatActivity {

    private EditText hour;
    private EditText minute;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tuesday);

        hour = findViewById(R.id.tueH);
        minute = findViewById(R.id.tueM);


        if(hour.getText().toString().equals("")||minute.getText().toString().equals("")) findViewById(R.id.tueSet).setEnabled(false);

        hour.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!hour.getText().toString().equals("")&&!minute.getText().toString().equals("")) findViewById(R.id.tueSet).setEnabled(true);
                else findViewById(R.id.tueSet).setEnabled(false);
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        minute.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!hour.getText().toString().equals("")&&!minute.getText().toString().equals("")) findViewById(R.id.tueSet).setEnabled(true);
                else findViewById(R.id.tueSet).setEnabled(false);
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        findViewById(R.id.tueSet).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder er = new AlertDialog.Builder(Tuesday.this);
                er.setMessage("Please enter numbers that are within range.").setCancelable(true);

                hour = findViewById(R.id.tueH);
                int h = Integer.parseInt(hour.getText().toString());
                minute = findViewById(R.id.tueM);
                int m = Integer.parseInt(minute.getText().toString());
                if((h>23 || h<0) || (m>60 || m<0)) {
                    AlertDialog alert = er.create();
                    alert.setTitle("Incompatible input");
                    alert.show();
                }
                else {
                    int sum = Integer.parseInt(hour.getText().toString()) * 60//hours
                            + Integer.parseInt(minute.getText().toString());//minutes
                    Logic.setMaxTime(1,sum);// in minutes
                    Logic.setPlaceholder(1,h+" hours : "+m+" minutes");// for setting the value of current limits
                }



            }
        });

    }

}
