package app.amazing.yiti.jeff.myapplication;

public class Logic {




    private static double[] maxTime ={0,0,0,0,0,0,0}; // the max times of the days
    private static String[] placeholder = {"0","0","0","0","0","0","0"};// for the "current max time" section on activity week

    public Logic(){

    }
    public static String getPlaceholder(int i) {
        return placeholder[i];
    }

    public static void setPlaceholder(int i, String s) {
        Logic.placeholder[i] = s;
    }

    public static double getMaxTime(int i) {
        return maxTime[i];
    }

    public static void setMaxTime(int i, double d) {
        Logic.maxTime[i] = d;
    }
}
